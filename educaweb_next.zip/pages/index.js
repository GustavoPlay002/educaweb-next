import React, { useState } from 'react'

const courses = [
  { id: 'webdev-bootcamp', title: 'Web Dev Bootcamp (Front-end + Back-end)', price: 297, bullets: ['HTML, CSS, JS moderno', 'React + Next.js', 'Node + Express', 'Deploy e Git'], level: 'Intermediário', duration: '10 semanas' },
  { id: 'marketing-digital', title: 'Marketing Digital Prático', price: 197, bullets: ['Funil de vendas', 'Ads (Meta/Google)', 'SEO e Conteúdo', 'Email & Automação'], level: 'Iniciante → Intermediário', duration: '8 semanas' },
  { id: 'combo-growth', title: 'Combo: Desenvolvimento + Growth (Mentoria)', price: 497, bullets: ['Aulas + Mentoria ao vivo', 'Projetos reais', 'Feedback 1:1'], level: 'Avançado', duration: '12 semanas' }
]

export default function Home() {
  const [email, setEmail] = useState('')

  async function handleBuy(hotmartUrl) {
    // Redireciona para Hotmart (configurar NEXT_PUBLIC_HOTMART_URL em .env)
    if (hotmartUrl) {
      window.open(hotmartUrl, '_blank')
    } else {
      alert('Link do Hotmart não configurado. Use o botão de compra via Hotmart.')
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">EducaWeb</h1>
          <p className="text-sm text-gray-500">Cursos práticos de Desenvolvimento e Marketing</p>
        </div>
        <nav className="text-sm">
          <a href="#cursos" className="mr-4">Cursos</a>
          <a href="#contato">Contato</a>
        </nav>
      </header>

      <main className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-8">
        <section>
          <h2 className="text-3xl font-extrabold">Aprenda a construir produtos e vender online</h2>
          <p className="mt-4 text-gray-700">Cursos práticos com projetos reais: crie sites, lojas, funis de vendas e estratégias que convertem.</p>

          <div className="mt-6">
            <input className="px-3 py-2 border rounded w-full md:w-80" placeholder="Seu melhor email" value={email} onChange={e => setEmail(e.target.value)} />
            <div className="mt-3 flex gap-3">
              <button onClick={() => alert('Inscrição na lista enviada (modo POC)')} className="px-4 py-2 bg-blue-600 text-white rounded">Quero ser avisado</button>
            </div>
          </div>
        </section>

        <aside className="bg-white p-5 rounded shadow">
          <h3 className="font-semibold">O que você recebe</h3>
          <ul className="mt-3 text-sm space-y-1">
            <li>• Aulas gravadas</li>
            <li>• Projetos práticos</li>
            <li>• Grupo de alunos</li>
            <li>• Certificado digital</li>
          </ul>
        </aside>
      </main>

      <section id="cursos" className="mt-12">
        <h3 className="text-2xl font-bold">Cursos</h3>
        <div className="mt-6 grid gap-6 grid-cols-1 md:grid-cols-3">
          {courses.map(c => (
            <article key={c.id} className="bg-white p-5 rounded-xl shadow">
              <h4 className="text-lg font-semibold">{c.title}</h4>
              <p className="text-sm text-gray-500 mt-1">{c.level} • {c.duration}</p>
              <ul className="mt-3 text-sm space-y-1">{c.bullets.map((b,i)=> <li key={i}>• {b}</li>)}</ul>
              <div className="mt-4 flex items-center justify-between">
                <div><div className="text-2xl font-bold">R$ {c.price}</div><div className="text-xs text-gray-500">Pagamento via Hotmart</div></div>
                <div className="flex gap-2">
                  <button onClick={() => handleBuy(process.env.NEXT_PUBLIC_HOTMART_URL)} className="px-4 py-2 bg-blue-600 text-white rounded">Comprar</button>
                  <button onClick={() => alert('Amostra de aula: enviando vídeo gratuito para seu email (POC)')} className="px-3 py-2 border rounded">Aula Grátis</button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <footer className="mt-12 text-sm text-gray-500">© {new Date().getFullYear()} EducaWeb</footer>
    </div>
  )
}
