// Nota: neste pacote para Hotmart deixamos apenas um placeholder.
// Se você quiser integrar Stripe no futuro, substitua este handler por criação de Checkout Session.
export default function handler(req, res) {
  res.status(200).json({ message: 'Use Hotmart - configure NEXT_PUBLIC_HOTMART_URL' })
}
