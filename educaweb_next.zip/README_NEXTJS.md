    # EducaWeb Next.js - Deploy rápido

1) Instale dependências:
   npm install

2) Rodar em dev:
   npm run dev

3) Configurar variáveis de ambiente (crie um arquivo `.env.local` com as chaves do `.env.example`).

4) Para usar Stripe: crie conta em https://dashboard.stripe.com, pegue as chaves e cole em `.env.local`.

5) Deploy no Vercel:
   - Crie conta Vercel e conecte ao GitHub
   - Suba o repositório e configure as variáveis de ambiente no painel do Vercel
   - Deploy automático acontece ao fazer push

6) Se preferir Hotmart: crie o produto no painel do Hotmart e use o link do produto (NEXT_PUBLIC_HOTMART_URL) — o botão "Comprar via Hotmart" redirecionará ao checkout deles.

7) Hospedagem de vídeos: use Vimeo Pro/Cloudflare Stream e coloque o token em VIMEO_TOKEN; atualize as rotas de acesso aos vídeos conforme a lógica da sua entrega.

8) Testes: faça compra real de baixo valor (ou use teste do Stripe em modo test).
